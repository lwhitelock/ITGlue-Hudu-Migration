---
external help file: HuduAPI-help.xml
Module Name: HuduAPI
online version:
schema: 2.0.0
---

# New-HuduWebsite

## SYNOPSIS
Create a Website

## SYNTAX

```
New-HuduWebsite [-Name] <String> [[-Notes] <String>] [[-Paused] <String>] [-CompanyId] <Int32>
 [[-DisableDNS] <String>] [[-DisableSSL] <String>] [[-DisableWhois] <String>] [[-EnableDMARC] <String>]
 [[-EnableDKIM] <String>] [[-EnableSPF] <String>] [[-Slug] <String>] [-ProgressAction <ActionPreference>]
 [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
Uses Hudu API to create a website

## EXAMPLES

### EXAMPLE 1
```
New-HuduWebsite -CompanyId 1 -Name https://domain.com
```

## PARAMETERS

### -Name
Website name (e.g.
https://domain.com)

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Notes
Used to add additional notes to a website

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Paused
When true, website monitoring is paused

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -CompanyId
Used to associate website with company

```yaml
Type: Int32
Parameter Sets: (All)
Aliases: company_id

Required: True
Position: 4
Default value: 0
Accept pipeline input: False
Accept wildcard characters: False
```

### -DisableDNS
When true, dns monitoring is paused.

```yaml
Type: String
Parameter Sets: (All)
Aliases: disable_dns

Required: False
Position: 5
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DisableSSL
When true, ssl cert monitoring is paused.

```yaml
Type: String
Parameter Sets: (All)
Aliases: disable_ssl

Required: False
Position: 6
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DisableWhois
When true, whois monitoring is paused.

```yaml
Type: String
Parameter Sets: (All)
Aliases: disable_whois

Required: False
Position: 7
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -EnableDMARC
When true, DMARC monitoring is enabled.

```yaml
Type: String
Parameter Sets: (All)
Aliases: enable_dmarc

Required: False
Position: 8
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -EnableDKIM
When true, DKIM monitoring is enabled.

```yaml
Type: String
Parameter Sets: (All)
Aliases: enable_dkim

Required: False
Position: 9
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -EnableSPF
When true, SPF monitoring is enabled.

```yaml
Type: String
Parameter Sets: (All)
Aliases: enable_spf

Required: False
Position: 10
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Slug
Url identifier

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 11
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
